# 👁 Manglam Optical Shop – Website Setup Guide

## 📦 What's Included

```
manglam-optical/
├── index.html          ← Main website
├── css/style.css       ← All styles
├── js/main.js          ← Frontend logic
├── admin/index.html    ← Admin dashboard
├── server.js           ← Node.js backend
├── package.json        ← Dependencies
└── data/               ← Appointments stored here (auto-created)
```

---

## 🚀 OPTION A: Quick Static Hosting (No backend, free – Netlify/Vercel)

> Works instantly. Appointments saved in browser storage. No email/WhatsApp notifications.

### Step 1 – Upload to Netlify (FREE)
1. Go to https://netlify.com → Sign up free
2. Drag & drop the `manglam-optical` folder onto the Netlify dashboard
3. Your site is live in 30 seconds! 🎉
4. Click "Domain Settings" → Get a free `.netlify.app` URL

### Step 2 – Get a Custom Domain (Optional)
- Buy `manglamoptical.in` or `manglamopticaljaipur.com` from GoDaddy (~₹800/year)
- Connect it in Netlify → Domain Settings → Add custom domain

---

## 🖥️ OPTION B: Full Backend with Notifications (Node.js)

> Full features: email + WhatsApp alerts, server-side storage.

### Requirements
- Node.js v18+ (download from https://nodejs.org)
- A computer/VPS that stays on (or use Railway/Render for free)

### Step 1 – Install & Run Locally
```bash
# Navigate to the folder
cd manglam-optical

# Install dependencies
npm install

# Start the server
node server.js

# Open: http://localhost:3000
```

### Step 2 – Set Up Email Notifications (Gmail)
1. Go to your Google Account → Security → 2-Step Verification (enable it)
2. Go to: https://myaccount.google.com/apppasswords
3. Create an App Password for "Mail"
4. Copy the 16-character password

Then run the server with:
```bash
EMAIL_PASS="abcd efgh ijkl mnop" node server.js
```

Or on Windows:
```cmd
set EMAIL_PASS=abcdedghijklmnop && node server.js
```

### Step 3 – Set Up WhatsApp Notifications (Free via CallMeBot)

1. Save this number in your phone contacts: **+34 644 59 77 23** (CallMeBot)
2. Send this WhatsApp message to that number:
   ```
   I allow callmebot to send me messages
   ```
3. You'll receive an API key in reply (e.g., `123456`)
4. Run server with:
```bash
EMAIL_PASS="your-app-password" WA_API_KEY="123456" node server.js
```

---

## ☁️ OPTION C: Deploy to Railway (FREE cloud hosting with backend)

1. Go to https://railway.app → Sign up with GitHub
2. New Project → Deploy from GitHub repo
   - Or: Upload folder and deploy
3. Add Environment Variables in Railway dashboard:
   - `EMAIL_PASS` = your Gmail app password
   - `WA_API_KEY` = your CallMeBot API key
4. Railway gives you a free `.railway.app` URL

---

## 🌐 OPTION D: Deploy to Render (FREE)

1. Go to https://render.com → Sign up
2. New → Web Service → Connect your GitHub
3. Settings:
   - Build Command: `npm install`
   - Start Command: `node server.js`
4. Add environment variables same as above
5. Free `.onrender.com` URL

---

## 📊 Admin Dashboard

Visit: `https://your-site.com/admin`

Features:
- View all appointments
- Filter by status/service
- Search by name/phone
- Update appointment status
- Export to CSV
- Send WhatsApp directly to customer
- Dark/Light mode

---

## 📱 WhatsApp Integration Details

When someone books an appointment, you'll receive a WhatsApp message like:
```
🆕 NEW APPOINTMENT

👁 Manglam Optical Shop

👤 Name: Rahul Sharma
📞 Phone: 9876543210
🔬 Service: Eye Testing
📅 Date: 2026-04-01

Please confirm the appointment!
```

---

## 📧 Email Setup Checklist

- [x] Email: manglamopticaljaipur@gmail.com
- [ ] Enable 2-Step Verification on Gmail
- [ ] Create App Password
- [ ] Set EMAIL_PASS environment variable
- [ ] Test by submitting a booking

---

## 🔧 Customization

### Change Phone Number
In `index.html`, find all instances of `09829035802` and `919829035802` and replace.

### Change Colors
In `css/style.css`, update these variables:
```css
--primary: #0A3D91;   /* Royal Blue */
--accent: #00BFFF;    /* Neon Blue */
```

### Add More Services
In `index.html`, find the `<select name="service">` and add `<option>` tags.

### Change Business Hours
Search for `10 AM – 9 PM` in `index.html` and update.

---

## 📞 Support Info

- **Shop:** Manglam Optical Shop
- **Address:** G 180 Doctors Colony, 80 Feet Road, Chitrakoot, Vaishali Nagar, Jaipur 302021
- **Phone:** 098290 35802
- **Email:** manglamopticaljaipur@gmail.com
- **Hours:** 10:00 AM – 9:00 PM (All Days)

---

## ✅ Feature Checklist

- [x] Fully responsive (mobile-first)
- [x] Light/Dark mode with localStorage
- [x] Sticky navbar with hamburger menu
- [x] Hero section with animated text
- [x] About section with highlights
- [x] Services section (glassmorphism cards)
- [x] Product carousel/slider
- [x] Why Choose Us with counters
- [x] Appointment booking form
- [x] Success popup after booking
- [x] Google Maps embed
- [x] Testimonials section
- [x] Contact section
- [x] Footer with all links
- [x] Floating WhatsApp button
- [x] Offer popup (10% off)
- [x] Sunday free checkup banner
- [x] Admin dashboard
- [x] Export to CSV
- [x] Email notifications (with backend)
- [x] WhatsApp notifications (with backend)
- [x] SEO meta tags
- [x] Smooth scroll animations
- [x] Counter animations

---

© 2026 Manglam Optical Shop. All Rights Reserved.
