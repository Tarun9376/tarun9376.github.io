// ===== THEME TOGGLE =====
const themeToggle = document.getElementById('themeToggle');
const html = document.documentElement;
const savedTheme = localStorage.getItem('theme') || 'light';
html.setAttribute('data-theme', savedTheme);
themeToggle.querySelector('.theme-icon').textContent = savedTheme === 'dark' ? '☀️' : '🌙';

themeToggle.addEventListener('click', () => {
  const current = html.getAttribute('data-theme');
  const next = current === 'light' ? 'dark' : 'light';
  html.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
  themeToggle.querySelector('.theme-icon').textContent = next === 'dark' ? '☀️' : '🌙';
});

// ===== NAVBAR SCROLL =====
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 50);
  highlightNavLink();
});

// ===== HAMBURGER MENU =====
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('navLinks');
hamburger.addEventListener('click', () => {
  navLinks.classList.toggle('open');
  const spans = hamburger.querySelectorAll('span');
  if (navLinks.classList.contains('open')) {
    spans[0].style.transform = 'rotate(45deg) translate(5px,5px)';
    spans[1].style.opacity = '0';
    spans[2].style.transform = 'rotate(-45deg) translate(5px,-5px)';
  } else {
    spans.forEach(s => { s.style.transform = ''; s.style.opacity = ''; });
  }
});
navLinks.querySelectorAll('a').forEach(a => {
  a.addEventListener('click', () => {
    navLinks.classList.remove('open');
    hamburger.querySelectorAll('span').forEach(s => { s.style.transform=''; s.style.opacity=''; });
  });
});

// ===== ACTIVE NAV LINK =====
function highlightNavLink() {
  const sections = document.querySelectorAll('section[id]');
  const scrollY = window.scrollY + 100;
  sections.forEach(section => {
    const top = section.offsetTop;
    const height = section.offsetHeight;
    const id = section.getAttribute('id');
    const link = document.querySelector(`.nav-links a[href="#${id}"]`);
    if (link) {
      link.classList.toggle('active', scrollY >= top && scrollY < top + height);
    }
  });
}

// ===== REVEAL ON SCROLL =====
const reveals = document.querySelectorAll('.reveal');
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      setTimeout(() => entry.target.classList.add('visible'), i * 80);
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.1 });
reveals.forEach(el => observer.observe(el));

// ===== COUNTER ANIMATION =====
const counters = document.querySelectorAll('.counter');
const counterObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      animateCounter(entry.target);
      counterObs.unobserve(entry.target);
    }
  });
}, { threshold: 0.5 });
counters.forEach(c => counterObs.observe(c));

function animateCounter(el) {
  const target = +el.dataset.target;
  const duration = 2000;
  const step = target / (duration / 16);
  let current = 0;
  const timer = setInterval(() => {
    current += step;
    if (current >= target) { el.textContent = target; clearInterval(timer); return; }
    el.textContent = Math.floor(current);
  }, 16);
}

// ===== PRODUCT SLIDER =====
const slider = document.getElementById('productSlider');
const prevBtn = document.getElementById('sliderPrev');
const nextBtn = document.getElementById('sliderNext');
let sliderPos = 0;
const cardWidth = 244;

function getMaxScroll() {
  return slider.scrollWidth - slider.parentElement.clientWidth;
}
nextBtn.addEventListener('click', () => {
  sliderPos = Math.min(sliderPos + cardWidth * 2, getMaxScroll());
  slider.style.transform = `translateX(-${sliderPos}px)`;
});
prevBtn.addEventListener('click', () => {
  sliderPos = Math.max(sliderPos - cardWidth * 2, 0);
  slider.style.transform = `translateX(-${sliderPos}px)`;
});

// Drag scroll
let isDragging = false, startX, startScroll;
slider.addEventListener('mousedown', e => { isDragging = true; startX = e.pageX; startScroll = sliderPos; slider.style.cursor='grabbing'; });
window.addEventListener('mouseup', () => { isDragging = false; slider.style.cursor='grab'; });
window.addEventListener('mousemove', e => {
  if (!isDragging) return;
  const dx = startX - e.pageX;
  sliderPos = Math.max(0, Math.min(startScroll + dx, getMaxScroll()));
  slider.style.transform = `translateX(-${sliderPos}px)`;
});

// ===== OFFER POPUP =====
function closeOffer() {
  document.getElementById('offerPopup').classList.remove('active');
  document.getElementById('offerOverlay').classList.remove('active');
}
setTimeout(() => {
  document.getElementById('offerPopup').classList.add('active');
  document.getElementById('offerOverlay').classList.add('active');
}, 2500);

// ===== SUCCESS POPUP =====
function closeSuccess() {
  document.getElementById('successPopup').classList.remove('active');
  document.getElementById('successOverlay').classList.remove('active');
}

// ===== BOOKING FORM =====
const form = document.getElementById('bookingForm');
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = document.getElementById('submitBtn');
  btn.querySelector('.btn-text').style.display = 'none';
  btn.querySelector('.btn-loader').style.display = 'inline';
  btn.disabled = true;

  const data = {
    name: form.name.value,
    phone: form.phone.value,
    date: form.date.value,
    service: form.service.value,
    message: form.message.value,
    timestamp: new Date().toISOString()
  };

  try {
    // Save to local storage as backup
    const appointments = JSON.parse(localStorage.getItem('manglam_appointments') || '[]');
    appointments.push({ ...data, id: Date.now() });
    localStorage.setItem('manglam_appointments', JSON.stringify(appointments));

    // Try to send via backend API
    await fetch('/api/book', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    }).catch(() => {}); // Ignore network errors for static hosting

    // Show success
    form.reset();
    document.getElementById('successPopup').classList.add('active');
    document.getElementById('successOverlay').classList.add('active');
  } catch (err) {
    alert('Booking saved! We will contact you soon. 📞');
  } finally {
    btn.querySelector('.btn-text').style.display = 'inline';
    btn.querySelector('.btn-loader').style.display = 'none';
    btn.disabled = false;
  }
});

// ===== SMOOTH SCROLL for nav links =====
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const top = target.offsetTop - 72;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  });
});

// ===== SET MIN DATE =====
const dateInput = document.querySelector('input[type="date"]');
if (dateInput) {
  const today = new Date().toISOString().split('T')[0];
  dateInput.min = today;
}
