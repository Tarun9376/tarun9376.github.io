const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.PORT || 3000;

// ===== MIDDLEWARE =====
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// ===== APPOINTMENTS DB (JSON file) =====
const DB_PATH = path.join(__dirname, 'appointments.json');
if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, '[]');

function readAppointments() {
  try { return JSON.parse(fs.readFileSync(DB_PATH)); } catch { return []; }
}
function saveAppointments(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// ===== EMAIL CONFIG (Nodemailer via Gmail) =====
// Replace with your Gmail App Password (Settings > Security > App Passwords)
const EMAIL_FROM = process.env.EMAIL_FROM || 'manglamopticaljaipur@gmail.com';
const EMAIL_PASS = process.env.EMAIL_PASS || 'YOUR_APP_PASSWORD_HERE';
const ADMIN_EMAIL = 'manglamopticaljaipur@gmail.com';

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: { user: EMAIL_FROM, pass: EMAIL_PASS },
});

// ===== WHATSAPP CONFIG (CallMeBot API - Free) =====
// Register at https://www.callmebot.com/blog/free-api-whatsapp-messages/
const WA_PHONE = process.env.WA_PHONE || '919829035802';
const WA_API_KEY = process.env.WA_APIKEY || 'YOUR_CALLMEBOT_API_KEY';

async function sendWhatsApp(message) {
  try {
    const encoded = encodeURIComponent(message);
    const url = `https://api.callmebot.com/whatsapp.php?phone=${WA_PHONE}&text=${encoded}&apikey=${WA_API_KEY}`;
    const res = await fetch(url);
    const text = await res.text();
    console.log('[WhatsApp] Response:', text);
  } catch (err) {
    console.error('[WhatsApp] Error:', err.message);
  }
}

async function sendEmailNotification(appt) {
  const mailOptions = {
    from: EMAIL_FROM,
    to: ADMIN_EMAIL,
    subject: `🗓 New Appointment - ${appt.name} | Manglam Optical`,
    html: `
      <div style="font-family:Poppins,Arial,sans-serif;max-width:600px;margin:auto;border:1px solid #e0e8ff;border-radius:16px;overflow:hidden;">
        <div style="background:linear-gradient(135deg,#0A3D91,#1565d8);padding:32px;text-align:center;">
          <h1 style="color:#fff;font-size:22px;margin:0;">New Appointment Booking</h1>
          <p style="color:rgba(255,255,255,0.85);margin:8px 0 0;">Manglam Optical Shop</p>
        </div>
        <div style="padding:32px;">
          <table style="width:100%;border-collapse:collapse;">
            <tr><td style="padding:10px;font-weight:600;color:#555;width:140px;">Name</td><td style="padding:10px;color:#222;">${appt.name}</td></tr>
            <tr style="background:#f8faff;"><td style="padding:10px;font-weight:600;color:#555;">Phone</td><td style="padding:10px;color:#222;"><a href="tel:${appt.phone}">${appt.phone}</a></td></tr>
            <tr><td style="padding:10px;font-weight:600;color:#555;">Date</td><td style="padding:10px;color:#222;">${appt.date}</td></tr>
            <tr style="background:#f8faff;"><td style="padding:10px;font-weight:600;color:#555;">Service</td><td style="padding:10px;color:#0A3D91;font-weight:600;">${appt.service}</td></tr>
            <tr><td style="padding:10px;font-weight:600;color:#555;">Message</td><td style="padding:10px;color:#222;">${appt.message || '—'}</td></tr>
          </table>
          <div style="margin-top:24px;text-align:center;">
            <a href="https://wa.me/91${appt.phone}" style="background:#25D366;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;">
              📲 Reply on WhatsApp
            </a>
          </div>
        </div>
        <div style="background:#f8faff;padding:16px 32px;text-align:center;font-size:12px;color:#888;">
          Manglam Optical Shop | G 180 Doctors Colony, Vaishali Nagar, Jaipur | 098290 35802
        </div>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('[Email] Notification sent to', ADMIN_EMAIL);
  } catch (err) {
    console.error('[Email] Error:', err.message);
  }
}

// ===== API ROUTES =====

// POST /api/appointments - Create appointment
app.post('/api/appointments', async (req, res) => {
  const { name, phone, date, service, message } = req.body;

  if (!name || !phone || !date || !service) {
    return res.status(400).json({ success: false, error: 'Required fields missing.' });
  }

  const appt = {
    id: Date.now().toString(),
    name, phone, date, service,
    message: message || '',
    status: 'pending',
    createdAt: new Date().toISOString(),
  };

  // Save to DB
  const all = readAppointments();
  all.push(appt);
  saveAppointments(all);
  console.log('[Appointment] Saved:', appt.id, appt.name);

  // Send notifications (non-blocking)
  sendEmailNotification(appt).catch(console.error);
  sendWhatsApp(
    `🔔 New Appointment!\n👤 ${name}\n📞 ${phone}\n📅 ${date}\n💼 ${service}\n💬 ${message || 'No message'}`
  ).catch(console.error);

  res.json({ success: true, id: appt.id });
});

// GET /api/appointments - Admin: list all appointments
app.get('/api/appointments', requireAdmin, (req, res) => {
  const all = readAppointments();
  res.json({ success: true, appointments: all.reverse() });
});

// PATCH /api/appointments/:id/status - Update status
app.patch('/api/appointments/:id/status', requireAdmin, (req, res) => {
  const { status } = req.body;
  const all = readAppointments();
  const idx = all.findIndex(a => a.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false });
  all[idx].status = status;
  saveAppointments(all);
  res.json({ success: true });
});

// DELETE /api/appointments/:id
app.delete('/api/appointments/:id', requireAdmin, (req, res) => {
  let all = readAppointments();
  all = all.filter(a => a.id !== req.params.id);
  saveAppointments(all);
  res.json({ success: true });
});

// Admin auth (simple token-based)
function requireAdmin(req, res, next) {
  const token = req.headers['x-admin-token'] || req.query.token;
  const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'manglam2026admin';
  if (token !== ADMIN_TOKEN) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

// Admin panel
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, '../admin/index.html'));
});

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

app.listen(PORT, () => {
  console.log(`\n✅ Manglam Optical Server running on http://localhost:${PORT}`);
  console.log(`📊 Admin Panel: http://localhost:${PORT}/admin`);
  console.log(`📋 Admin Token: ${process.env.ADMIN_TOKEN || 'manglam2026admin'}\n`);
});
