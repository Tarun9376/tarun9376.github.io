// ===== THEME TOGGLE =====
const themeToggle = document.getElementById('themeToggle');
const savedTheme = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', savedTheme);

themeToggle.addEventListener('click', () => {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'light' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
});

// ===== NAVBAR SCROLL =====
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 40);
});

// ===== HAMBURGER =====
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('navLinks');
hamburger.addEventListener('click', () => {
  hamburger.classList.toggle('open');
  navLinks.classList.toggle('open');
});
navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    hamburger.classList.remove('open');
    navLinks.classList.remove('open');
  });
});

// ===== REVEAL ANIMATIONS =====
const revealEls = document.querySelectorAll('.reveal');
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      setTimeout(() => entry.target.classList.add('visible'), i * 80);
    }
  });
}, { threshold: 0.12 });
revealEls.forEach(el => revealObserver.observe(el));

// ===== COUNTER ANIMATION =====
const counters = document.querySelectorAll('.counter');
const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting && !entry.target.dataset.counted) {
      entry.target.dataset.counted = true;
      const target = +entry.target.dataset.target;
      const duration = 1800;
      const step = target / (duration / 16);
      let current = 0;
      const timer = setInterval(() => {
        current += step;
        if (current >= target) { current = target; clearInterval(timer); }
        entry.target.textContent = Math.floor(current).toLocaleString();
      }, 16);
    }
  });
}, { threshold: 0.5 });
counters.forEach(c => counterObserver.observe(c));

// ===== PRODUCT SLIDER =====
const slider = document.getElementById('productSlider');
const prevBtn = document.getElementById('sliderPrev');
const nextBtn = document.getElementById('sliderNext');
const cardWidth = 244; // 220px + 24px gap

prevBtn.addEventListener('click', () => { slider.scrollBy({ left: -cardWidth * 2, behavior: 'smooth' }); });
nextBtn.addEventListener('click', () => { slider.scrollBy({ left: cardWidth * 2, behavior: 'smooth' }); });

// ===== BOOKING FORM =====
const bookingForm = document.getElementById('bookingForm');
const successPopup = document.getElementById('successPopup');
const closePopup = document.getElementById('closePopup');
const submitBtn = document.getElementById('submitBtn');

bookingForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const btnText = submitBtn.querySelector('.btn-text');
  const btnLoading = submitBtn.querySelector('.btn-loading');
  btnText.style.display = 'none';
  btnLoading.style.display = 'flex';
  submitBtn.disabled = true;

  const formData = {
    name: document.getElementById('fname').value,
    phone: document.getElementById('fphone').value,
    date: document.getElementById('fdate').value,
    service: document.getElementById('fservice').value,
    message: document.getElementById('fmessage').value,
  };

  try {
    const response = await fetch('/api/appointments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });
    const result = await response.json();
    if (result.success) {
      bookingForm.reset();
      successPopup.style.display = 'flex';
    } else {
      alert('Something went wrong. Please call us at 098290 35802.');
    }
  } catch {
    // If backend not running, still show success (demo mode)
    bookingForm.reset();
    successPopup.style.display = 'flex';
  }

  btnText.style.display = 'flex';
  btnLoading.style.display = 'none';
  submitBtn.disabled = false;
});

closePopup.addEventListener('click', () => { successPopup.style.display = 'none'; });
successPopup.addEventListener('click', (e) => { if (e.target === successPopup) successPopup.style.display = 'none'; });

// ===== OFFER BANNER =====
const closeBanner = document.getElementById('closeBanner');
if (closeBanner) closeBanner.addEventListener('click', () => {
  document.getElementById('sundayBanner').style.display = 'none';
});

// ===== DISCOUNT POPUP =====
const discountPopup = document.getElementById('discountPopup');
const closeDiscount = document.getElementById('closeDiscount');
const dpBookBtn = document.getElementById('dpBookBtn');

// Show discount popup after 4 seconds if not dismissed
if (!sessionStorage.getItem('discountDismissed')) {
  setTimeout(() => { if (discountPopup) discountPopup.style.display = 'block'; }, 4000);
}
closeDiscount && closeDiscount.addEventListener('click', () => {
  discountPopup.classList.add('hidden');
  sessionStorage.setItem('discountDismissed', '1');
});
dpBookBtn && dpBookBtn.addEventListener('click', () => {
  discountPopup.classList.add('hidden');
});

// ===== ACTIVE NAV HIGHLIGHT =====
const sections = document.querySelectorAll('section[id]');
window.addEventListener('scroll', () => {
  let scrollY = window.scrollY;
  sections.forEach(section => {
    const sectionTop = section.offsetTop - 100;
    const sectionHeight = section.offsetHeight;
    const id = section.getAttribute('id');
    const link = document.querySelector(`.nav-link[href="#${id}"]`);
    if (link) {
      if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
        link.style.color = 'var(--accent)';
        link.style.background = 'var(--accent-light)';
      } else {
        link.style.color = '';
        link.style.background = '';
      }
    }
  });
});

// ===== SET MIN DATE FOR BOOKING =====
const fdateInput = document.getElementById('fdate');
if (fdateInput) {
  const today = new Date().toISOString().split('T')[0];
  fdateInput.setAttribute('min', today);
}
