const express = require('express');
const nodemailer = require('nodemailer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// ===== CONFIG =====
const CONFIG = {
  shopPhone: '919829035802',
  shopEmail: 'manglamopticaljaipur@gmail.com',
  shopName: 'Manglam Optical Shop',
  shopAddress: 'G 180 Doctors Colony, 80 Feet Road, Chitrakoot, Vaishali Nagar, Jaipur 302021',
  // Email config – fill in after getting Gmail App Password
  emailUser: process.env.EMAIL_USER || 'manglamopticaljaipur@gmail.com',
  emailPass: process.env.EMAIL_PASS || 'YOUR_APP_PASSWORD_HERE',
  // CallMeBot WhatsApp API key (free) – fill after setup
  whatsappApiKey: process.env.WA_API_KEY || '',
};

// ===== DATA FILE =====
const DATA_FILE = path.join(__dirname, 'data', 'appointments.json');
if (!fs.existsSync(path.join(__dirname, 'data'))) fs.mkdirSync(path.join(__dirname, 'data'));
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]');

function readAppointments() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch { return []; }
}
function saveAppointments(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// ===== MIDDLEWARE =====
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// ===== EMAIL TRANSPORT =====
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: { user: CONFIG.emailUser, pass: CONFIG.emailPass }
});

async function sendEmailNotification(appointment) {
  const { name, phone, date, service, message } = appointment;
  const emailHtml = `
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;border:1px solid #e0e8f8;border-radius:16px;overflow:hidden;">
      <div style="background:linear-gradient(135deg,#0A3D91,#1a5cc8);padding:32px;text-align:center;">
        <h1 style="color:#fff;margin:0;font-size:24px;">👁 New Appointment</h1>
        <p style="color:rgba(255,255,255,0.85);margin:8px 0 0;">Manglam Optical Shop</p>
      </div>
      <div style="padding:32px;">
        <h2 style="color:#0A3D91;margin-bottom:20px;">Appointment Details</h2>
        <table style="width:100%;border-collapse:collapse;">
          <tr><td style="padding:10px;color:#888;width:120px;font-weight:600;">👤 Name</td><td style="padding:10px;font-weight:600;">${name}</td></tr>
          <tr style="background:#f4f8ff;"><td style="padding:10px;color:#888;font-weight:600;">📞 Phone</td><td style="padding:10px;"><a href="tel:${phone}" style="color:#0A3D91;">${phone}</a></td></tr>
          <tr><td style="padding:10px;color:#888;font-weight:600;">🔬 Service</td><td style="padding:10px;">${service}</td></tr>
          <tr style="background:#f4f8ff;"><td style="padding:10px;color:#888;font-weight:600;">📅 Date</td><td style="padding:10px;">${date}</td></tr>
          <tr><td style="padding:10px;color:#888;font-weight:600;">💬 Message</td><td style="padding:10px;">${message || 'No message'}</td></tr>
        </table>
        <div style="margin-top:24px;padding:16px;background:#dcfce7;border-radius:10px;border-left:4px solid #16a34a;">
          <p style="margin:0;color:#15803d;font-weight:600;">✅ Please contact the customer to confirm their appointment.</p>
        </div>
        <div style="margin-top:20px;text-align:center;">
          <a href="https://wa.me/91${phone}" style="display:inline-block;padding:12px 28px;background:#25D366;color:#fff;border-radius:50px;text-decoration:none;font-weight:700;">💬 WhatsApp Customer</a>
        </div>
      </div>
      <div style="background:#f4f8ff;padding:20px;text-align:center;font-size:12px;color:#888;">
        ${CONFIG.shopName} · ${CONFIG.shopAddress}
      </div>
    </div>`;

  await transporter.sendMail({
    from: `"${CONFIG.shopName}" <${CONFIG.emailUser}>`,
    to: CONFIG.shopEmail,
    subject: `🆕 New Appointment: ${name} – ${service}`,
    html: emailHtml
  });
}

async function sendWhatsAppNotification(appointment) {
  if (!CONFIG.whatsappApiKey) return;
  const { name, phone, date, service } = appointment;
  const msg = encodeURIComponent(
    `🆕 NEW APPOINTMENT\n\n👁 Manglam Optical Shop\n\n👤 Name: ${name}\n📞 Phone: ${phone}\n🔬 Service: ${service}\n📅 Date: ${date}\n\nPlease confirm the appointment!`
  );
  const url = `https://api.callmebot.com/whatsapp.php?phone=${CONFIG.shopPhone}&text=${msg}&apikey=${CONFIG.whatsappApiKey}`;
  await fetch(url).catch(err => console.log('WhatsApp API error:', err.message));
}

// ===== ROUTES =====

// Book appointment
app.post('/api/book', async (req, res) => {
  try {
    const { name, phone, date, service, message } = req.body;
    if (!name || !phone || !service) {
      return res.status(400).json({ success: false, message: 'Missing required fields' });
    }
    const appointment = {
      id: Date.now(), name, phone, date, service,
      message: message || '', status: 'new',
      timestamp: new Date().toISOString()
    };
    const appointments = readAppointments();
    appointments.push(appointment);
    saveAppointments(appointments);

    // Send notifications (non-blocking)
    Promise.all([
      sendEmailNotification(appointment).catch(e => console.log('Email error:', e.message)),
      sendWhatsAppNotification(appointment).catch(e => console.log('WA error:', e.message))
    ]);

    res.json({ success: true, id: appointment.id, message: 'Appointment booked successfully!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get all appointments
app.get('/api/appointments', (req, res) => {
  res.json(readAppointments());
});

// Update appointment status
app.patch('/api/appointments/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const { status } = req.body;
  const appointments = readAppointments();
  const idx = appointments.findIndex(a => a.id === id);
  if (idx === -1) return res.status(404).json({ success: false });
  appointments[idx].status = status;
  saveAppointments(appointments);
  res.json({ success: true });
});

// Delete appointment
app.delete('/api/appointments/:id', (req, res) => {
  const id = parseInt(req.params.id);
  let appointments = readAppointments();
  appointments = appointments.filter(a => a.id !== id);
  saveAppointments(appointments);
  res.json({ success: true });
});

// Health check
app.get('/api/health', (req, res) => res.json({ status: 'ok', shop: CONFIG.shopName }));

app.listen(PORT, () => {
  console.log(`\n🚀 Manglam Optical Server running on http://localhost:${PORT}`);
  console.log(`📊 Admin Panel: http://localhost:${PORT}/admin`);
  console.log(`🌐 Website: http://localhost:${PORT}`);
  console.log(`\n⚠️  Setup Required:`);
  console.log(`   1. Set EMAIL_PASS env variable (Gmail App Password)`);
  console.log(`   2. Set WA_API_KEY env variable (CallMeBot key)`);
  console.log(`   3. Run: node server.js\n`);
});
